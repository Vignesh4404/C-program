/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>  
#include <string.h>
void admin();
void stud();
void signup();
void login();
void addbk();
void lend();
void retur();
void search();
void saverep();
void vuerep();
struct stu
{
    char a[100];
    int p;
}s[100];
struct book
{
    char bn[200],an[100];
    int p,f;
}bk[100];
int t=0,st=0;
FILE *p;
int main()
{
    int n;
    printf("*****Library Management System************\n");
    while(1)
    {
        printf("1.Admin\n2.Student\n3.Exit\nEnter the choice:");
        scanf("%d",&n);
        if(n==1)
            admin();
        if(n==2)
            stud();
        else
        break;
    }
    return 0;
}
void admin()
{
    int n,d,p;
    printf("Enter Admin ID:");
    scanf("%d",&d);
    printf("Enter Admin Password:");
    scanf("%d",&p);
    if(d==123 &&p==2345)
    {
        printf("****Login Successfully****\n");
        while(1)
        {
            printf("1.Add book\n2.View report\n3.Save report\n4.Exit\nEnter the Choice:");
            scanf("%d",&n);
            if(n==1)
                addbk();
            else if(n==2)
                vuerep();
            else if(n==3)
                saverep();    
            else if(n==4)
            {
                printf("Exit\n");
                main();
                break;
            }
        }
    }
    else
      printf("Enter a Valid ID/Password");
}
void stud()
{
    int n;
    while(1)
    {
        printf("\n1.Signup\n2.Login\n3.Exit\nEnter a chioce : ");
        scanf("%d",&n);
        if(n==1)
            signup();
        else if(n==2)
            login();
        else
            break;
    }
}
void signup(){
    int n,i;
    printf("How many Student: ");
    scanf("%d",&n);
    for(i=1;i<=n;i++)
    {
        printf("Enter a Student name:");
        scanf("%s",s[st].a);
        printf("Enter a Student password:");
        scanf("%d",&s[st].p);
        printf("student id is : %d\n",st+200);
        st++;
    }
}
void login()
{
    int n,tt;
    printf("Enter Student Id : ");
    scanf("%d",&n);
    printf("Enter Student password : ");
    scanf("%d",&tt);
    if(s[n-200].p==tt)
    {
        while(1)
        {
            printf("\n1.View book\n2.Search book\n3.Lend book\n4.return book\n5.Exit\nEnter a chioce : ");
            scanf("%d",&n);
            if(n==1)
                vuerep();
            else if(n==2)
                search();
            else if(n==3)
                lend();
            else if(n==4)
                retur();
            else
                break;
        }
    }
    else
        printf("Invalid id Or password ");
}
void addbk()
{  
     int n,i;
    printf("\nEnter a no.of book : ");
    scanf("%d",&n);
    //  p=fopen("savereport.txt","r+");
    //  fclose(p);
    for(i=0;i<n;i++)
    {
        printf("Enter a book name :");
        scanf("%s",bk[t].bn);
        printf("Enter a author name :");
        scanf("%s",bk[t].an);
        printf("Enter a price :");
        scanf("%d",&bk[t].p);
        printf("book id is : %d\n",t+100);
        bk[i].f=1;
        t++;
    }
}
void saverep()
{
  int i=0;
   p=fopen("savereport.txt","w+");
   fprintf(p,"book name   author name  price  book id \n");
   fprintf(p,"---------   -----------  -----  -------\n");
   for(i=0;i<t;i++){
    fprintf(p,"%s          %s           %d     %d\n",bk[i].bn,bk[i].an,bk[i].p,i+100); 
}
    fclose(p);
   printf("report  submit Successfully\n");
}
void vuerep()
{
    int i=0,f=1;
//   p=fopen("savereport.txt","r+");
    printf("List of Books in Stock:\n");
    printf("Book ID\tBook Name\tAuthor Name\tBook Price\t\n");
       for(i=0;i<t;i++,printf("\n"))
       {
           if(bk[i].f==1)
           {
            // printf("book name : %s \nauthor name : %s\nprice : %d\nbook id : %d\n\n",bk[i].bn,bk[i].an,bk[i].p,i+100);
            printf(" %d\t%s \t\t %s\t\t  %d\t\t\n",i+100,bk[i].bn,bk[i].an,bk[i].p);
            f=0;
           }
       }
  //  fclose(p);
   if(f)
        printf("Not Available book \n");
}
void lend()
{
    int n;
    printf("Enter a Book Id :");
    scanf("%d",&n);
    if(100<=n && n<(t+100))
    {
		if(bk[n-100].f==0)
		  {
			  printf("**********Book is already Taken**********");
		  }
		  else 
		  {
            bk[n-100].f=0;
            printf("********Lend Successfully***************");
	      }
    }
    else
        printf("Invalid Book id");
}
void retur()
{
    int n;
    printf("Enter a Book Id :");
    scanf("%d",&n);
    if(100<=n && n<(t+100))
    {
		if(bk[n-100].f==1)
		{
		  printf("*********You cannot Return this book****************");
		} 
		else 
		{
			bk[n-100].f=1;
			printf("**************Return Successfully************************");
	   }
    }
    else
        printf("Invalid Book id");
}
void search()
{
    char a[100];
    int i,f=1;
    printf("Enter a Book name :");
    scanf("%s",a);
    for(i=0;i<t;i++)    
    {
        if(!strcmp(bk[i].bn,a))
        {
            printf("book name : %s\nauthor name : %s\nprice : %d\nbook id : %d\n\n",bk[i].bn,bk[i].an,bk[i].p,i+100);
            f=0;
            break;
        }
    }
    if(f)
        printf("book not avaliable ... ");
}
 